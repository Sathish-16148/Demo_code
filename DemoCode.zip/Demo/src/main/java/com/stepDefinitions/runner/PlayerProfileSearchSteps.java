package com.stepDefinitions.runner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.Assert.*;

import io.cucumber.java.en.*;


public class PlayerProfileSearchSteps {
    WebDriver driver;

    @Given("^I navigate to the ESPNcricinfo homepage$")
    public void navigateToHomepage() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Sathish\\eclipse-workspace_newHlb\\Demo\\target\\Driver\\chromedriver.exe"); 
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.espncricinfo.com/");
    }

    @When("^I use the search bar to search for \"([^\"]*)\"$")
    public void searchForPlayer(String playerName) {
    	driver.findElement(By.cssSelector(".icon-search-outlined.ds-text-icon-inverse.ci-nav-item.ci-nav-hover")).click();
        WebElement searchBar = driver.findElement(By.cssSelector("input[placeholder='Search Players, Teams or Series']"));
        searchBar.sendKeys(playerName);
        searchBar.submit();
    }

    @Then("^I should see the player profile of \"([^\"]*)\" with accurate information$")
    public void verifyPlayerProfile(String playerName) {
        WebElement playerProfile = driver.findElement(By.xpath("//span[contains(text(),'" + playerName + "')]"));
        assertNotNull("Player profile not found", playerProfile);
        assertTrue("Incorrect player information displayed", playerProfile.getText().contains(playerName));
        driver.quit();
    }
}